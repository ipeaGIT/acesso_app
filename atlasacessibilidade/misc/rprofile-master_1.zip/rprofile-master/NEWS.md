# 0.1.1
  * Bug: No wifi signals no longer returns an error
  * Bug: width passed to options incorrectly
  * Bug: export `lsos()` on startup (not `llsos()`)
  * Tweak: In `cp()` pressing enter now exits the function
  * Tweak: Removing warning when creating a new directory via `op()`
  * Tweak: Normalise paths in `cp()`
  * Add: details on current RStudio project
  * Add: `menu.graphics = FALSE` to `set_options()`
 
# 0.1.0

  * Added a `NEWS.md` file to track changes to the package.
  * First version
